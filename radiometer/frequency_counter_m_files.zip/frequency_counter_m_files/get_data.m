% This script communicates with the program TSL230R_FreqCounter running on an
% arduino support atmega uc. It instructs the uc how the TSL230R's sensitivity
% and frequency scaling should be programmed and receives the frequency count
% output from the uc.%
%
% The atmega uc is controlled with simple commands over the serial line in the
% format caaa, where 'c' means command and 'aaa' is a 3 character argument.
% s - stands for sensitivity, valid arguments are 000, 001, 010, and 100.
% f - stands for frequency scaling, valid arguments are 001, 002, 010, and 100.
% l - stands for light, valid arguments are 000 or 001. the light command will 
%       set a pin specified in the uc code to low or high which can be used to 
%       drive an LED or switch a transitor or relay off/on. the light command
%       also instructs the uc to start outputting frequency data.
% m - stands for mute, arguments 000-999 are valid but are ignored, however, a
%       valid argument must be present for formatting reasons. the mute command
%       instructs the uc to turn off the light and stop outputting frequency 
%       data.
%
% The full scale frequency from the TSL230R equals (1.1 MHz)/fscale.
% The maximum input frequency that can be read by the FreqCounter code running 
% on the atmega is about 8 MHz when signal duty cycle is 50%.
% Therefore there is no reason to use any fscale other than 1.
%
% The variable prefix fO is "ef oh" not "ef zero". It's how the output frequency
% is denoted in the TSL230R's datasheet. The output frequency is recorded when
% the lamp is on (fO_light) and off (fO_dark) so that the photodiode's thermal 
% current, measured by fO_dark, can be removed.
%
% fO_light and fO_dark are not automatically saved. You should check for
% spurious data before saving. If bad samples are present, remove them and run
% the script save_data.
%
%
% Octave NOTES
% Writing anything to the serial port ends all transmissions.
% calling fflush after fprintf is necessary to write to the serial port. fputs
% doesn't require fflush, but fputs doesn't exist in MATLAB.
%
% MATLAB NOTES
% fgetl doesn't return -1 when it reaches the end of the stream. Therefore, the
% uc sends a special end of transmission 'EOT' signal.
%
%
%

%**** USER SUPPLIED DATA ****%

% OCTAVE_VERSION is a built in function, exist returns 5, which is nonzero
if (exist('OCTAVE_VERSION')) % GNU Octave in Linux
	port = '/dev/ttyUSB0';
else % 	MATLAB in Windows
	port = 'COM9';
end

% WAIT_TIME is the amount of time to allow the serial buffer to fill with
% samples. If something goes wrong and the uc doesn't stop transmitting
% frequencies, then when MAXNUM_SAMPLES have been read the loop will break
% preventing an infinite loop. The actual number of samples saved will not 
% exceed MAXNUM_SAMPLES-1. One is subtracted because sometimes the first
% sample is spurious so it is automatically removed.
WAIT_TIME = 5; %seconds
MAXNUM_SAMPLES = 51;

sensitivity = 1;
fscale = 1;
distance = 0.07; % distance of light source from detector, [m]

% this is used by the script save_data.
fname = 'test.mat';

%****************************%

fO_light = -1;
fO_dark = -1;

if (exist('OCTAVE_VERSION'))
	serial_write = @(spr, sstr) fputs(spr, sstr);
else
	serial_write = @(spr, sstr) fprintf(spr, '%s', sstr);
end

sp = serial_open(port);

disp('Please turn on lamp. Then press any key to continue.')
pause();
disp('Thank you. Proceeding.')

scmd = sprintf('s%03d', sensitivity);
serial_write(sp, scmd); %set sensitivity
fcmd = sprintf('f%03d', fscale);
serial_write(sp, fcmd); %set frequency scaling

serial_write(sp, 'l001'); %turn on lamp, and tell uc to start transmitting
pause(WAIT_TIME); %wait for data to be generated and transmitted to buffer
serial_write(sp, 'm001'); %tell uc to stop transmitting
k = 1;
f = fgetl(sp);
while (ischar(f) && ~strcmp(f, 'EOT') && k < MAXNUM_SAMPLES)
	fO_light(k) = str2double(f);
	k = k+1;
	f = fgetl(sp);
end
% once fgetl has returned -1 (reached EOF) the serial port must be
% closed and re-opened to get any new data.
fclose(sp);

disp('Please turn off lamp. Then press any key to continue.')
pause();
disp('Thank you. Proceeding.')

%re-open serial port
sp = serial_open(port);

serial_write(sp, 'l000'); %turn off lamp, and tell uc to start transmitting
pause(WAIT_TIME); %wait for data to be generated and transmitted to buffer
serial_write(sp, 'm000'); %tell uc to stop transmitting
k = 1;
f = fgetl(sp);
while (ischar(f) && ~strcmp(f, 'EOT') && k < MAXNUM_SAMPLES)
	fO_dark(k) = str2double(f);
	k = k+1;
	f = fgetl(sp);
end
fclose(sp);

sp = serial_open(port);
serial_write(sp, 's000'); %tell TSL230R to stop disable output
serial_write(sp, 'm000'); %turn off light pin and set transmit to false
fclose(sp)

% sometimes the first data points are spurious so discard them.
fO_light = fO_light(2:end).'
fO_dark = fO_dark(2:end).'

disp('Check for spurious data before saving.');
rsp = input('Do you want to save? [(y)es/(n)o]: ', 's');
if (~isempty(rsp) && lower(rsp(1)) == 'y')
	save_data;
end

