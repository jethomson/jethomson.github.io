%SERIAL_OPEN - Opens the device file supplied as the argument "port" for
%              serial communication in the manner required by GNU Octave
%              or MATLAB.
%
% GNU Octave and MATLAB handle opening a serial port differently. This function
% detects which environment it is in and opens the serial port accordingly.
%
% Syntax:  sp = serial_open(port)
%
% Inputs:
%    port - the device file or communications port
%
% Outputs:
%    sp - the handle for sending and receiving data over the serial port
%
% Example:
%    sp = serial_open('/dev/ttyUSB0'); % UNIX like systems
%    sp = serial_open('C0M9'); % Windows
%
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also:
%
% Author: Jonathan Thomson
% Work:
% email:
% Website: http://jethomson.wordpress.com
%

function sp = serial_open(port)
	if (exist('OCTAVE_VERSION'))
		sp = fopen(port, 'r+');
	else
		% Terminator values are line feed ('\r\n') when receiving data
		% and nothing (no terminator) when sending data.
		sp = serial(port, 'BaudRate', 9600, ...
		            'Terminator', {'CR/LF', ''});
		fopen(sp);
	end
end
