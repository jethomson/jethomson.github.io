%TSL230R_fO_to_irradiance - Converts the frequency output of the TSL230R to
%                           irradiance when given the light source's spectrum.
%
% Syntax:  [Ee, E] = TSL230R_fO_to_irradiance(lambda, X, fO, sensitivity)
%
% Inputs:
%    lambda - the spectrum's wavelength scale.
%         X - the light sources spectrum.
%        fO - the output of the TSL230R. (small eff, big OH)
%    sensitivity - the sensitivity setting of the TSL230R
%
% Outputs:
%    Ee - the light source's spectral irradiance.
%     E - the light source's irradiance.
%
% Example:
%    load('TSL230R_actinic.mat')
%    fO = mean(fO_light) - mean(fO_dark);
%    mu = 415;
%    FWHM = 30;
%    Xactinic = 75*exp(-2.7726*((so.lambda-mu)/FWHM).^2); % model spectrogram
%    Ee_meter = TSL230R_fO_to_irradiance(so.lambda, Xactinic, fO, sensitivity);
%
%    load('TSL230R_actinic.mat')
%    fO = mean(fO_light) - mean(fO_dark);
%    load('actinic_spectrograph.mat'); % loads spctgrph
%    Xactinic = image2spectrum(spctgrph); % spectrogram created from a picture
%    Ee_meter = TSL230R_fO_to_irradiance(so.lambda, Xactinic, fO, sensitivity);
%
%
% Other m-files required: none
% Subfunctions: none
% MAT-files required: none
%
% See also: NONE
%
% Author: Jonathan Thomson
% Work:
% email:
% Website: http://jethomson.wordpress.com
%

%NOTES:
% This m-file uses the frequency output from the TSL230R, it's spectral
% responsivity, and a mathematical model of a lamp's spectrum or a
% spectrogram to determine the lamp's irradiance and spectral irradiance.
%
% Assuming the lamp's spotlight fills an area greater than the photodiode's
% aperture then the radiant spectral power (or power spectral density) entering
% the photodiode is the light's spectral irradiance [uW/(cm^2)/nm] multiplied
% by the area of the aperture [cm^2].
% [cm^2]*[uW/(cm^2)/nm] = [uW/nm]
%
% Once a photon has entered the photodiode it has a wavelength dependent
% probability of creating a electron/hole pair that produce a differential
% current. This conversion from spectral radiant power to current is
% represented by the photodiode's spectral responsivity [A/uW]. All of the
% differential currents naturally integrate to form the photodiode's total
% photocurrent because they enter the same conductor.
% integral{[A/uW]*[uW/nm]*[nm]} = [A]
%
% Finally the current-to-frequency converter transforms the current to the
% output frequency and scales it by the programmed frequency scaler.
% [kHz/A]*[A] = [kHz]
%
% The total transformation from spectral irradiance to frequency is represented
% by: [kHz] = [kHz/A]*integral{[A/uW]*[cm^2]*[uW/(cm^2)/nm]*[nm]}
%
% The datasheet only gives the normalized spectral responsivity (as a plot) and
% the system's responsivity at 640 nm, Re(640 nm) = 0.77 [kHz/(uW/(cm^2))]
% (when sensitivity is 100x and frequency scaler is 1x). The mat file Re_s1.mat
% is the spectral responsivity of the TSL230R for a sensitivity of 1. It was
% created by converting the datasheet's graph of the normalized spectral
% responsivity into a point-series and multiplying it by the system's
% responsivity at 640 nm with a frequency scaler of 1 and a sensitivity of 1,
% which is 0.0077 [kHz/(uW/(cm^2))].
%
% If the spectral irradiance incident on the TSL230R photodiode is represented
% by A(lambda) then fO = integral{Re(lambda)*A(lambda) dlambda} from 0 to inf.
% However, A(lambda) is unknown so we must use X(lambda) which has the same
% shape as A(lambda) but is off by an unknown multiplicative constant k
% because it is an uncalibrated spectrum (i.e. A(lambda) = k*X(lambda)).
% We can then use our mathematical model of the TSL230R to find the frequency
% output that would result if a light source with a spectrum X(lambda) incident
% on the sensor: fX = integral{Re(lambda)*X(lambda) dlambda}
%
% Since fO is known, fX can be found, and the TSL230R is a linear system, k can
% be found simply: k = fO/fX
% Therefore we have obtained the desired result Ee = k*X.
% The accuracy of your result depends on the accuracy of the TSL230R as well
% as how well X(lambda) matches the shape of A(lambda).
%
% Extra Info
% The detector area changes when the sensitivity is changed. The frequency
% scale of fO vs. Ee changes when the frequency scaling is changed.
%
% Full scale frequency equals (1.1 MHz)/fscale
%
% lambda must be in nm and between 250 nm and 1200 nm inclusive.
%

function [Ee, E] = TSL230R_fO_to_irradiance(lambda, X, fO, sensitivity)

	s = filesep;
	% load lambda [nm] and
	% system responsivity at 1x sensitivity, Re_s1
	load(['data' s 'essential_data_sets' s 'Re_s1.mat'])

	% Re(640 nm) = sensitivity*0.0077 [kHz/(uW/cm^2)]
	Re = sensitivity*Re_s1; % [kHz/(uW/(cm^2))]

	% interpolate so we can use lambda [nm] instead of lambda_Re
	Rei = interp1(lambda_Re, Re, lambda, 'spline', 0);

	% fX is the frequency that would be output if the model lamp shined
	% light with a spectral irradiance X on the photodiode.
	dl = mean(diff(lambda)); % [nm]
	fX = trapz(Rei.*X).*dl; % [kHz]

	k = fO./fX; % scaling factor, [dimensionless]

	Ee = k.*X; % spectral irradiance of lamp, [uW/(cm^2)/nm]
	E = trapz(Ee).*dl; % irradiance of lamp, [uW/(cm^2)]

end

