%

s = filesep;
dl = 0.1;
lambda = 250:dl:1200;

load(['data' s 's1f2_cyan_LED_6.mat'])

fO = (mean(fO_light) - mean(fO_dark))/1000;

% mathematically model lamp's spectrum as a gaussian curve with a peak 
% wavelength at 505 nm and full width at half maximum of 20 nm
func_lamp = @(mu, FWHM) e.^(-0.5*((lambda-mu)/(FWHM/(2*sqrt(2*log(2))))).^2);
X = func_lamp(505, 20); % [uW/(nm*cm^2)]

[Ee, E] = TSL230R_fO_to_irradiance(lambda, X, fO, sensitivity);

disp(['irradiance (E) : ' num2str(E) ' uW/cm^2 at distance '...
	  num2str(distance) ' m.'])

plot(lambda, Ee, 'g')
title('Spectral irradiance from cyan LED')
xlabel('wavelength [nm]')
ylabel('spectral irradiance [uW/(cm^2)/nm]')

g = 683.002; % [lm/W]  (lumens per watt of green light at 555 nm)
load(['data' s 'luminosity_function_1924e']);
Vi = interp1(lambda_V, V, lambda, 'spline', 0);
Ev = g*trapz(Vi.*Ee).*dl; % illuminance

disp(['illuminance (Ev) : ' num2str(Ev) ' ulm/cm^2 at distance '...
	  num2str(distance) ' m.'])

