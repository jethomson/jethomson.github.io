#!/bin/bash
IFS=$(echo -en "\n\b")
for file in $ROOT/Project/Examples/*
do
if [ `basename $file` != CVS ]
  then 
     echo "$file"
     ln -sf "$file" `basename ${file/ /_}`
  fi
done
ln -sf $ROOT/Project/Demo .

