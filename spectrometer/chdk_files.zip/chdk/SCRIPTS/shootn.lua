--[[
@title Multi-shot with Remote
-- Author: jthomson
@param t Tv
@default t -3
@param n Number of Shots
@default n 5
]]

function done_beep()
		play_sound(4)
		sleep(200)
		play_sound(4)
		sleep(400)
		play_sound(4)
		sleep(200)
		play_sound(4)
end

set_zoom(6)    --focal length 19.6 mm
sleep(2000)    --sleep to give motor time to zoom, otherwise camera crashes

set_iso_mode(1)  --ISO 80, no set_user function, so display isn't updated
--set_user_av96(480)  --aperture f/5.6
set_user_av_by_id(15)  --aperture f/5.6

-- see chdk/platform/<model>/shooting.c
--  '33' = (1/2000) seconds, minimum at zoom 0 (bias frames)
--  '31' = (1/1250) seconds, minimum at zoom 6
--   '0' = 1 second
--  '-3' = 2 seconds (default, used for taking light frames)
-- '-12' = 15 seconds, maximum (dark current stability test)
set_user_tv_by_id(t)

--set to manual focus so set_focus can be used
p=get_prop(133)
if p ~= 1 then
  repeat  
    click("down")
    p=get_prop(133) -- indicates camera is in manual focus mode
  until p == 1
end

set_focus(357)  --minimum focus possible for zoom 6

--press the "erase" button (aka "plus/minus exposure") to switch from
--the manual focus assist window back to the normal view
--this is only necessary if you have "MF-Point Zoom" set to On.
--click("erase")

press("shoot_half")
repeat 
	sleep(1)
until get_shooting() == true
release("shoot_half")

while 1 do
	wait_click(200)
	if is_pressed "remote" then
		set_focus(357) -- if LCD is turned off, manual focus is lost.
		for i = 1,n do
			shoot()
		end
		done_beep()
	end
end
