--[[
@title Get Tv, Av, ISO, etc
-- Author: jthomson 
]]
function get_values()
	press("shoot_half")
	repeat 
		sleep(1)
	until get_shooting() == true

    --"get_dof" get the depth of sharpness in mm 
    --"get_far_limit" get the border zone ranged acceptable sharpness mm 
    --"get_focus" 
    --"get_hyp_dist" get hyperfocal distance 
    --"get_iso_market" get "marketing" ISO
    --"get_iso_mode" obtain ISO mode (the former get_iso) 
    --"get_iso_real" get real "value" ISO 
    --"get_iso" obtain ISO mode 
    --"get_near_limit" get dipped border zone acceptable sharpness

	tv1=get_user_tv_id()
	tv2=get_tv96()  -- get_user_tv96 returns the same as get_user_tv_id
	av1=get_user_av_id()
	av2=get_user_av96()

	i=get_iso_mode()
	z=get_zoom()
	subjdist=get_focus()

	release("shoot_half")

	print("tvid " .. tv1 .. " tv96 " .. tv2)
	print("avid " .. av1 .. " av96 " .. av2)
	print("ISO " .. i .. " zoom " .. z)
	print("focus " .. subjdist)
end

get_values()

--test the setting of values
--set_zoom(6)    --focal length 19.6 mm
--sleep(2000)
--
--set_iso_mode(1)  --ISO 80, no set_user function, so OSD isn't updated
--set_user_av96(480)  --aperture f/5.6
--set_user_tv_by_id(0)    --shutter time 1"

--Set to manual focus (so we can use set_focus command).
--p=get_prop(133)
--if p ~= 1 then
--  repeat  
--    click("down")
--    p=get_prop(133)
--  until p == 1
--end
--
--set_focus(357)
--
--get_values()
